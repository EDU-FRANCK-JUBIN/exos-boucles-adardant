﻿using System;
using System.Collections.Generic;

namespace Test
{
	class Program
	{
		static void Main(string[] args)
		{
			for (int i = 0; i <= 20; i++)
			{
				if (i % 2 == 0)
				{
					Console.WriteLine(i);
				}
			}

			Console.WriteLine("Entrez un nombre");
			string a = Console.ReadLine();
			int res = 0;

			for (int j = 0; j <= Int32.Parse(a); j++)
			{
				res = res + j;
			}

			Console.WriteLine(res);

			Console.WriteLine("Rentrez cinq nombres");
			List<double> nombresList = new List<double>();
			for (int i = 1; i <= 5; i++)
			{
				double nombreEnDouble;
				string k = Console.ReadLine();
				Double.TryParse(k, out nombreEnDouble);
				nombresList.Add(nombreEnDouble);
			}

			Console.WriteLine("La moyenne est" + CalculMoyenne(nombresList).ToString());

			Console.WriteLine(CalculSommeEntiers(1, 10));
			Console.WriteLine(CalculSommeIntersection());

		}

		static int CalculSommeEntiers(int x, int y)
		{
			int res = 0;
			for (int i = x; i <= y; i++)
			{
				res += i;
			}
			return res;
		}


		static double CalculMoyenne(List<double> nombresList)
		{
			double res = 0;
			foreach (double nombre in nombresList)
			{
				res += nombre;
			}
			return res / nombresList.Count;
		}

		static int CalculSommeIntersection()
		{
			List<int> liste3 = new List<int>();
			for (int i = 3; i <= 100; i += 3)
			{
				liste3.Add(i);
			}

			List<int> liste5 = new List<int>();
			for (int i = 5; i <= 100; i += 5)
			{
				liste5.Add(i);
			}

			int res = 0;
			foreach (int nombre3 in liste3)
			{
				foreach (int nombre5 in liste5)
				{
					if (nombre3 == nombre5)
						res += nombre3 * 2;
				}
			}
			return res;
		}
	}
}
